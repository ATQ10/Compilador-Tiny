/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jlexcompiler;

/**
 *
 * @author HP
 */
public enum Tokens {
    Reservada,
    Program,
    If,
    Then,
    Else,
    Fi,
    Do,
    Until,
    While,
    Read,
    Write,
    Float,
    Int,
    Bool,
    True,
    False,
    Not,
    And,
    Or,
    Suma,
    Resta,
    Multiplicacion,
    Division,
    Potencia,
    Menor_que,
    Menor_o_igual,
    Mayor_que,
    Mayor_o_igual,
    Igual_que,
    Diferente_que,
    Igual,
    Punto_y_coma,
    Coma,
    Abre_parentesis,
    Cierra_parentesis,
    Abre_llave,
    Cierra_llave,
    Identificador,
    Numero,
    Comentario,
    ERROR
}
